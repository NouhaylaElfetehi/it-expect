import { LightningElement, track, wire } from 'lwc';
import getEvents from '@salesforce/apex/EventController.getEvents';
import saveEvent from '@salesforce/apex/EventController.saveEvent';
import deleteEvent from '@salesforce/apex/EventController.deleteEvent';
import registerForEvent from '@salesforce/apex/EventController.registerForEvent';

export default class EventManager extends LightningElement {
    @track events = [];
    @wire(getEvents)
    eventName = '';
    eventLocation = '';
    eventDescription = '';
    eventDate = '';
    wiredEvents(result) {
        if (result.data) {
            this.events = result.data;
        } else if (result.error) {
            console.error('Erreur lors de la récupération des événements :', result.error);
        }
    }
    connectedCallback() {
        this.fetchEvents();
    }

    handleNameChange(event) {
        this.eventName = event.target.value;
    }

    handleLocationChange(event) {
        this.eventLocation = event.target.value;
    }

    handleDescriptionChange(event) {
        this.eventDescription = event.target.value;
    }

    handleDateChange(event) {
        this.eventDate = event.target.value;
    }

    async fetchEvents() {
        const result = await getEvents();
        this.events = result;
    }
    async saveEvent() {
        try {
            await saveEvent({
                name: this.eventName,
                location: this.eventLocation,
                description: this.eventDescription,
                date: this.eventDate
            });
            this.clearForm(); 
            await this.fetchEvents();
        } catch (error) {
            console.error('Error saving event:', error);
        }
    }
    
    async deleteEvent(event) {
        const selectedRows = this.template.querySelector('lightning-datatable').getSelectedRows();
        if (selectedRows.length === 0) {
            console.error('Aucun événement sélectionné pour suppression.');
            return;
        }
    
        try {
            await deleteEvent({ eventId: selectedRows[0].Id });
            await this.fetchEvents();
        } catch (error) {
            console.error('Erreur lors de la suppression de l\'événement :', error);
        }
    }
    
    
    async registerForEvent(event) {
        const selectedRows = this.template.querySelector('lightning-datatable').getSelectedRows();
        if (selectedRows.length === 0) {
            console.error('Aucun événement sélectionné pour inscription.');
            return;
        }
    
        try {
            await registerForEvent({ eventId: selectedRows[0].Id });
            await this.fetchEvents();
        } catch (error) {
            console.error('Erreur lors de l\'inscription à l\'événement :', error);
        }
    }

    async fetchEvents() {
        try {
            const result = await getEvents();
            this.events = result; 
        } catch (error) {
            console.error('Erreur lors de la récupération des événements :', error);
        }
    }

    
    handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
    
        switch (actionName) {
            case 'register':
                this.registerForEvent({ detail: { row } });
                break;
            case 'delete':
                this.deleteEvent({ detail: { row } });
                break;
            default:
        }
    }
    
    
    get columns() {
        return [
            { label: 'Nom', fieldName: 'Name' },
            { label: 'Lieu', fieldName: 'Lieu__c' },
            { label: 'Description', fieldName: 'Description__c' },
            { label: 'Date', fieldName: 'Date__c' }
        ];
    }
}
